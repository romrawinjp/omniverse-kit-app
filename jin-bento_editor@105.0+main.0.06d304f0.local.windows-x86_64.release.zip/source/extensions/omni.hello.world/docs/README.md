# Simple UI Extension Template

The simplest python extension example. Use it as a starting point for your extensions.
