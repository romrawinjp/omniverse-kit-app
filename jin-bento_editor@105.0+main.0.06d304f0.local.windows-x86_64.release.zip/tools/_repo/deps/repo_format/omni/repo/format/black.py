import asyncio
import logging
import multiprocessing
import os
import sys
import time

import omni.repo.man

from . import vendor_directory
from .legal import LegalFormatter, create_legal_formatter
from .utils import (
    gather_with_concurrency,
    get_all_files,
    get_modified_files,
    run_process,
    teamcity_report_fail,
    teamcity_start_test,
    teamcity_stop_test,
)

logger = logging.getLogger(__name__)


def format_py(
    path: str,
    config: dict,
    verify: bool = False,
    force: bool = False,
    modified_only: bool = False,
    list_only: bool = False,
    copyright: bool = False,
) -> int:
    """Format using python black formatter.

    Args:
        path (str): Path to format.
        config (dict): Repo config.
        verify (bool, optional): If `True` don't write the files back, just return the status. Return code 0 means nothing would change.

    Returns:
        int: Return code.
    """

    tool_config = config.get("repo_format", {})
    python_config = tool_config.get("python", {})
    if copyright:
        python_config["maintain_legal_blurbs"] = True

    legal_formatter = create_legal_formatter(tool_config, python_config, "#")

    run_isort = python_config.get("run_isort", True)

    line_length = python_config.get("line_length", 120)
    python_version = python_config.get("python_version", "py37")

    repo_folders = config.get("repo", {}).get("folders", {})

    build_path = repo_folders["build"]

    # There are a couple of places where we want to just log to file
    # rather than spam the console on a non-verbose run.
    logging_level = getattr(logging, config.get("repo").get("logging", "warn").upper())
    verbose = True if logging_level <= 20 else False

    # Enable event loop that support subprocess on windows:
    if sys.platform == "win32":
        asyncio.set_event_loop(asyncio.ProactorEventLoop())
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    # Prepare list of files
    if os.path.isfile(path):
        files = [path]
    else:
        omni.repo.man.print_log(f"[{__name__}] searching for files in: '{path}'", logging.INFO)
        files = get_all_files(path, python_config.get("files", {}), modified_only)
    if not files:
        omni.repo.man.print_log(f"[{__name__}] no files found to run.", logging.INFO)
        sys.exit(0)

    # Last run time
    os.makedirs(build_path, exist_ok=True)
    lastrun_file = os.path.join(build_path, ".lastpythonformat")
    lastrun_time = 0  # effectively makes us process all files
    if not force and not verify and not list_only and not modified_only and os.path.isfile(lastrun_file):
        with open(lastrun_file, "r") as f:
            lastrun_time = float(f.readline())

    # Work only on changed file
    files = [path for path in files if os.path.getmtime(path) > lastrun_time]

    if list_only:
        omni.repo.man.print_log(f"[{__name__}] found {len(files)} files to run.", logging.INFO)
        omni.repo.man.print_log("\n".join(files), logging.INFO)
        return 0

    # By default use number of threads for numbers of jobs
    job_count = python_config.get("job_count", 0)
    if job_count <= 0:
        job_count = multiprocessing.cpu_count()

    # We run isort in parallel.
    isort_tasks = []
    if run_isort:
        for file in files:
            isort_tasks.append(_run_isort(file, verify, verbose))

    # We run black in chunks of files to avoid exceeding Windows line limits.
    black_tasks = _chunk_black_tasks(files, job_count, line_length, python_version, verify, verbose)

    omni.repo.man.print_log(
        f"[{__name__}] {'verifying' if verify else 'formatting'} {len(files)} files (job count: {job_count})",
        logging.INFO,
    )

    fail_count = 0
    if isort_tasks:
        fail_count += asyncio.run(run_tasks(job_count, isort_tasks, vendor_directory))
    fail_count += asyncio.run(run_tasks(1, black_tasks, vendor_directory))

    if not verify:
        with open(lastrun_file, "w") as f:
            f.write(str(time.time()))

    if fail_count:
        omni.repo.man.print_log(
            f"failed: {fail_count} out of {len(isort_tasks) + len(files)} commands, see above.", logging.ERROR
        )
        return 1

    if legal_formatter:
        try:
            if verify:
                fail_count = 0
                for file in files:
                    ok = legal_formatter.verify_file(file)
                    if ok:
                        omni.repo.man.print_log(f"[{__name__}] [legal_formatter] verified: {file}", logging.INFO)
                    else:
                        omni.repo.man.print_log(f"[legal_formatter] verification failed for: {file}", logging.ERROR)
                        fail_count += 1
                if fail_count:
                    return fail_count
            else:
                modified_files = get_modified_files()
                for file in files:
                    has_changed = file in modified_files
                    legal_formatter.format_file(file, has_changed)
        except RuntimeError as exc:
            omni.repo.man.print_log(f"{exc}", logging.ERROR)
            return 1

    return 0


def _process_result(tool, file, args, returncode, stdout, verify, verbose):
    if verify:
        if returncode == 0:
            # Restore this behavior of only printing verified files with --verbose.
            if verbose:
                omni.repo.man.print_log(f"[{__name__}] [{tool}] verified: {file}", logging.INFO)
        else:
            omni.repo.man.print_log(
                f"[{__name__}] [{tool}] python code format verification failed for: {file}", logging.ERROR
            )

            # TC report
            message = f"[{tool}] python code format verification failed"
            test_name = "%s: %s: %s" % (tool, file, message)
            teamcity_start_test(test_name)
            teamcity_report_fail(test_name, "Error", message)
            teamcity_stop_test(test_name)

    else:
        if returncode == 0:
            omni.repo.man.print_log(f"[{__name__}] [{tool}] formatted: {file}", logging.INFO)
        else:
            omni.repo.man.print_log(f"[{tool}] cmd failed: {args}, stdout:\n{stdout}", logging.WARNING)


def _process_black_results(tool, files, args, returncode, stdout, verify, verbose):
    """Black now runs multiple file checks in parallel. For that it requires a bit
    more processing."""

    filtered_stdout = stdout.split(os.linesep)
    failures = 0
    for f in files:
        local_stdout = ""
        file_stdout = [x for x in filtered_stdout if f in x]
        if file_stdout:
            # There should at all times just be 1 reference to our file.
            local_stdout = file_stdout[0]

        # Since we now batch up hundreds of files per process,
        # some might fail to format and some might succeed or no-op.
        # We want to reflect actual errors.
        local_returncode = returncode
        if not local_stdout or local_stdout == f"reformatted {f}":
            local_returncode = 0

        if local_returncode != 0:
            failures += 1
        _process_result(tool, f, args + [f], local_returncode, local_stdout, verify, verbose)

    return failures


def _chunk_black_tasks(files, job_count, line_length, python_version, verify, verbose):
    """
    Due to conflicts with parallel executions of Black from read/write stomping of a cache file in APP_DATA,
    we call one Black process with a variable number of workers based on job_count.
    Due to the Windows character limit, both platforms will chunk the number of files such that our args
    do not exceed 32766. We'll then process N number of tasks in serial and let Black handle parallelization.
    """
    args = [
        sys.executable,
        "-m",
        "black",
        "-l",
        str(line_length),
        "-t",
        python_version,
        "--workers",
        str(job_count),
    ]

    windows_character_limit = 32000 - len(" ".join(args))  # leave a little buffer just in case

    file_chunk = ""
    file_chunks = []
    for file in files:
        file_chunk += file + " "

        if len(file_chunk) >= windows_character_limit:
            file_chunks.append(file_chunk)
            file_chunk = ""

    # Grab the straggler files and then build tasks.
    if file_chunk != "":
        file_chunks.append(file_chunk)

    tasks = []
    for chunk in file_chunks:
        tasks.append(_run_black(args, chunk.split(" ")[:-1], verify, verbose))

    return tasks


async def _run_black(args, files, verify, verbose):
    local_args = args + files
    if verify:
        local_args.insert(3, "--check")
    returncode, stdout = await run_process(local_args)
    failures = _process_black_results("black", files, local_args, returncode, stdout, verify, verbose)
    return returncode, failures


async def _run_isort(file, verify, verbose):
    args = [sys.executable, "-m", "isort", "--profile", "black", file]
    if verify:
        args.append("--check")
    returncode, stdout = await run_process(args)
    _process_result("isort", file, args, returncode, stdout, verify, verbose)
    failures = 0
    if returncode != 0:
        failures = 1
    return returncode, failures


async def run_tasks(job_count, tasks, vendor_directory):
    fail_count = 0
    with omni.repo.man.change_envvar("PYTHONPATH", str(vendor_directory)):
        for returncode, failures in await gather_with_concurrency(job_count, tasks):
            if returncode != 0:
                fail_count += failures
    return fail_count
