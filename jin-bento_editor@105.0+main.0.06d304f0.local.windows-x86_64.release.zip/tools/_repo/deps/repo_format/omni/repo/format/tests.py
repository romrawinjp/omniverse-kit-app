__copyright__ = " Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved."
__license__ = """
NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
"""

import os
import shutil
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True


class BaseTestCase(unittest.TestCase):
    def setUp(self):
        self.output_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.output_dir)


class CommonTests(BaseTestCase):
    def test():
        pass


if __name__ == "__main__":
    unittest.main()
