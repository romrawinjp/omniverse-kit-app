__copyright__ = " Copyright (c) 2019-2021, NVIDIA CORPORATION. All rights reserved."
__license__ = """
NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
"""

import argparse
import logging
import os
import sys
from typing import List

from .black import format_py
from .clang import (
    DEFAULT_CLANG_VERSION,
    DEFAULT_CPP_FILE_EXCLUDE_PATTERNS,
    DEFAULT_CPP_FILE_PATTERNS,
    format_cpp,
)

logger = logging.getLogger(__name__)

# Load version from root VERSION file
ROOT_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", "..", "..")
VERSION = open(f"{ROOT_DIR}/VERSION").read()


def setup_argument_parser(parser: argparse.ArgumentParser):
    parser.prog = "format"
    parser.description = "Format all C++ code (with clang-format) and all python code (with black)."
    parser.add_argument(
        "-p",
        "--python-only",
        action="store_true",
        dest="python_only",
        required=False,
        help="Only run python code formatting.",
    )
    parser.add_argument(
        "-c", "--cpp-only", action="store_true", dest="cpp_only", required=False, help="Only run C++ code formatting."
    )
    parser.add_argument("-v", "--verify", action="store_true", dest="verify", required=False, default=False)
    parser.add_argument("-m", "--modified", action="store_true", dest="modified_only", required=False, default=False)
    parser.add_argument(
        "-l",
        "--list",
        action="store_true",
        dest="list_only",
        required=False,
        default=False,
        help="Only list files and exit.",
    )
    parser.add_argument("--force", action="store_true", dest="force", required=False, default=False)

    parser.add_argument(
        "--py-copyright",
        action="store_true",
        dest="python_copyright",
        required=False,
        default=False,
        help="Include the copyright at the top of python files. Default: False (for now)",
    )


def get_default_argument_parser() -> argparse.ArgumentParser:
    """Default argument parser for format tool"""

    parser = argparse.ArgumentParser()
    setup_argument_parser(parser)
    return parser


def format_all(
    config: dict,
    python_only: bool,
    cpp_only: bool,
    verify: bool,
    modified_only: bool,
    python_copyright: bool = False,
    force: bool = False,
    list_only: bool = False,
):
    """Format both C++ code and python.

    Args:
        config (dict): Tool config
        python_only (bool): Skip C++ code formatting.
        cpp_only (bool): Skip python code formatting.
        verify (bool): If `True` don't write the files back, but exit with error code if files require formatting.
        modified_only (bool): Only run clang-format on files with uncommitted changes
        python_copyright (bool): Add copyright and license to Python files
        force (bool): Ignore timestamp check and run clang-format on all specified files
    """

    repo_folders = config["repo"]["folders"]

    # C++ format:
    if not python_only:
        return_code = format_cpp(
            root=repo_folders["root"],
            config=config,
            verify=verify,
            config_file=__file__,
            modified_only=modified_only,
            force=force,
            list_only=list_only,
        )
        if verify and return_code != 0:
            logger.error("C++ formatting verification failed.")
            sys.exit(return_code)

    # Python format:
    if not cpp_only:
        return_code = format_py(
            repo_folders["root"],
            config=config,
            verify=verify,
            force=force,
            modified_only=modified_only,
            list_only=list_only,
            copyright=python_copyright,
        )
        if verify and return_code != 0:
            logger.error("Python formatting verification failed.")
            sys.exit(return_code)


def setup_repo_tool(parser, config):
    setup_argument_parser(parser)

    def run_repo_tool(options, config):
        format_all(
            config,
            options.python_only,
            options.cpp_only,
            options.verify,
            modified_only=options.modified_only,
            python_copyright=options.python_copyright,
            force=options.force,
            list_only=options.list_only,
        )

    return run_repo_tool
